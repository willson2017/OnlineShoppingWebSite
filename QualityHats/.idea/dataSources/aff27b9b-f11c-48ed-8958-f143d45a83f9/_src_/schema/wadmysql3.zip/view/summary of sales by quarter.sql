CREATE VIEW `summary of sales by quarter` AS
  SELECT
    `wadmysql3`.`orders`.`ShippedDate` AS `ShippedDate`,
    `wadmysql3`.`orders`.`OrderID`     AS `OrderID`,
    `order subtotals`.`Subtotal`       AS `Subtotal`
  FROM (`wadmysql3`.`orders`
    JOIN `wadmysql3`.`order subtotals` ON ((`wadmysql3`.`orders`.`OrderID` = `order subtotals`.`OrderID`)))
  WHERE (`wadmysql3`.`orders`.`ShippedDate` IS NOT NULL);
