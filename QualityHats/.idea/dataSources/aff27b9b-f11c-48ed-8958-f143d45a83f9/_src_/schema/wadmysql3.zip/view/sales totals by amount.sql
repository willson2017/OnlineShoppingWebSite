CREATE VIEW `sales totals by amount` AS
  SELECT
    `order subtotals`.`Subtotal`          AS `SaleAmount`,
    `wadmysql3`.`orders`.`OrderID`        AS `OrderID`,
    `wadmysql3`.`customers`.`CompanyName` AS `CompanyName`,
    `wadmysql3`.`orders`.`ShippedDate`    AS `ShippedDate`
  FROM ((`wadmysql3`.`customers`
    JOIN `wadmysql3`.`orders` ON ((`wadmysql3`.`customers`.`CustomerID` = `wadmysql3`.`orders`.`CustomerID`))) JOIN
    `wadmysql3`.`order subtotals` ON ((`wadmysql3`.`orders`.`OrderID` = `order subtotals`.`OrderID`)))
  WHERE ((`order subtotals`.`Subtotal` > 2500) AND
         (`wadmysql3`.`orders`.`ShippedDate` BETWEEN '1997-01-01' AND '1997-12-31'));
