CREATE VIEW `products above average price` AS
  SELECT
    `wadmysql3`.`products`.`ProductName` AS `ProductName`,
    `wadmysql3`.`products`.`UnitPrice`   AS `UnitPrice`
  FROM `wadmysql3`.`products`
  WHERE (`wadmysql3`.`products`.`UnitPrice` > (SELECT avg(`wadmysql3`.`products`.`UnitPrice`)
                                               FROM `wadmysql3`.`products`));
