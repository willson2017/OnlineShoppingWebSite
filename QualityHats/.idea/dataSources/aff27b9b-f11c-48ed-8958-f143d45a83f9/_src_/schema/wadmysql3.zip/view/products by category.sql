CREATE VIEW `products by category` AS
  SELECT
    `wadmysql3`.`categories`.`CategoryName`  AS `CategoryName`,
    `wadmysql3`.`products`.`ProductName`     AS `ProductName`,
    `wadmysql3`.`products`.`QuantityPerUnit` AS `QuantityPerUnit`,
    `wadmysql3`.`products`.`UnitsInStock`    AS `UnitsInStock`,
    `wadmysql3`.`products`.`Discontinued`    AS `Discontinued`
  FROM (`wadmysql3`.`categories`
    JOIN `wadmysql3`.`products` ON ((`wadmysql3`.`categories`.`CategoryID` = `wadmysql3`.`products`.`CategoryID`)))
  WHERE (`wadmysql3`.`products`.`Discontinued` <> 1);
