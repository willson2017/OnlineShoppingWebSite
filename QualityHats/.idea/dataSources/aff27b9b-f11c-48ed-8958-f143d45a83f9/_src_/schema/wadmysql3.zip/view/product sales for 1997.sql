CREATE VIEW `product sales for 1997` AS
  SELECT
    `wadmysql3`.`categories`.`CategoryName`                             AS `CategoryName`,
    `wadmysql3`.`products`.`ProductName`                                AS `ProductName`,
    sum(((((`wadmysql3`.`order details`.`UnitPrice` * `wadmysql3`.`order details`.`Quantity`) *
           (1 - `wadmysql3`.`order details`.`Discount`)) / 100) * 100)) AS `ProductSales`
  FROM (((`wadmysql3`.`categories`
    JOIN `wadmysql3`.`products` ON ((`wadmysql3`.`categories`.`CategoryID` = `wadmysql3`.`products`.`CategoryID`))) JOIN
    `wadmysql3`.`order details`
      ON ((`wadmysql3`.`products`.`ProductID` = `wadmysql3`.`order details`.`ProductID`))) JOIN `wadmysql3`.`orders`
      ON ((`wadmysql3`.`orders`.`OrderID` = `wadmysql3`.`order details`.`OrderID`)))
  WHERE (`wadmysql3`.`orders`.`ShippedDate` BETWEEN '1997-01-01' AND '1997-12-31')
  GROUP BY `wadmysql3`.`categories`.`CategoryName`, `wadmysql3`.`products`.`ProductName`;
