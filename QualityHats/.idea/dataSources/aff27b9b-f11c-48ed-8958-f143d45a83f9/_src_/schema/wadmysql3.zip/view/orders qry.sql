CREATE VIEW `orders qry` AS
  SELECT
    `wadmysql3`.`orders`.`OrderID`        AS `OrderID`,
    `wadmysql3`.`orders`.`CustomerID`     AS `CustomerID`,
    `wadmysql3`.`orders`.`EmployeeID`     AS `EmployeeID`,
    `wadmysql3`.`orders`.`OrderDate`      AS `OrderDate`,
    `wadmysql3`.`orders`.`RequiredDate`   AS `RequiredDate`,
    `wadmysql3`.`orders`.`ShippedDate`    AS `ShippedDate`,
    `wadmysql3`.`orders`.`ShipVia`        AS `ShipVia`,
    `wadmysql3`.`orders`.`Freight`        AS `Freight`,
    `wadmysql3`.`orders`.`ShipName`       AS `ShipName`,
    `wadmysql3`.`orders`.`ShipAddress`    AS `ShipAddress`,
    `wadmysql3`.`orders`.`ShipCity`       AS `ShipCity`,
    `wadmysql3`.`orders`.`ShipRegion`     AS `ShipRegion`,
    `wadmysql3`.`orders`.`ShipPostalCode` AS `ShipPostalCode`,
    `wadmysql3`.`orders`.`ShipCountry`    AS `ShipCountry`,
    `wadmysql3`.`customers`.`CompanyName` AS `CompanyName`,
    `wadmysql3`.`customers`.`Address`     AS `Address`,
    `wadmysql3`.`customers`.`City`        AS `City`,
    `wadmysql3`.`customers`.`Region`      AS `Region`,
    `wadmysql3`.`customers`.`PostalCode`  AS `PostalCode`,
    `wadmysql3`.`customers`.`Country`     AS `Country`
  FROM (`wadmysql3`.`customers`
    JOIN `wadmysql3`.`orders` ON ((`wadmysql3`.`customers`.`CustomerID` = `wadmysql3`.`orders`.`CustomerID`)));
