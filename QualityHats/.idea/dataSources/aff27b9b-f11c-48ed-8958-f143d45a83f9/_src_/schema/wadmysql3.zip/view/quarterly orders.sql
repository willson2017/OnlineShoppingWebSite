CREATE VIEW `quarterly orders` AS
  SELECT DISTINCT
    `wadmysql3`.`customers`.`CustomerID`  AS `CustomerID`,
    `wadmysql3`.`customers`.`CompanyName` AS `CompanyName`,
    `wadmysql3`.`customers`.`City`        AS `City`,
    `wadmysql3`.`customers`.`Country`     AS `Country`
  FROM (`wadmysql3`.`customers`
    JOIN `wadmysql3`.`orders` ON ((`wadmysql3`.`customers`.`CustomerID` = `wadmysql3`.`orders`.`CustomerID`)))
  WHERE (`wadmysql3`.`orders`.`OrderDate` BETWEEN '1997-01-01' AND '1997-12-31');
