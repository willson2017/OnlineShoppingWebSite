CREATE VIEW `order subtotals` AS
  SELECT
    `wadmysql3`.`order details`.`OrderID`                               AS `OrderID`,
    sum(((((`wadmysql3`.`order details`.`UnitPrice` * `wadmysql3`.`order details`.`Quantity`) *
           (1 - `wadmysql3`.`order details`.`Discount`)) / 100) * 100)) AS `Subtotal`
  FROM `wadmysql3`.`order details`
  GROUP BY `wadmysql3`.`order details`.`OrderID`;
