CREATE VIEW `current product list` AS
  SELECT
    `wadmysql3`.`products`.`ProductID`   AS `ProductID`,
    `wadmysql3`.`products`.`ProductName` AS `ProductName`
  FROM `wadmysql3`.`products`
  WHERE (`wadmysql3`.`products`.`Discontinued` = 0);
