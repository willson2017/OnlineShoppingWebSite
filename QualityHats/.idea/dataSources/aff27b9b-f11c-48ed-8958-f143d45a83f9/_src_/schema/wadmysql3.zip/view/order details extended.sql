CREATE VIEW `order details extended` AS
  SELECT
    `wadmysql3`.`order details`.`OrderID`                          AS `OrderID`,
    `wadmysql3`.`order details`.`ProductID`                        AS `ProductID`,
    `wadmysql3`.`products`.`ProductName`                           AS `ProductName`,
    `wadmysql3`.`order details`.`UnitPrice`                        AS `UnitPrice`,
    `wadmysql3`.`order details`.`Quantity`                         AS `Quantity`,
    `wadmysql3`.`order details`.`Discount`                         AS `Discount`,
    ((((`wadmysql3`.`order details`.`UnitPrice` * `wadmysql3`.`order details`.`Quantity`) *
       (1 - `wadmysql3`.`order details`.`Discount`)) / 100) * 100) AS `ExtendedPrice`
  FROM (`wadmysql3`.`products`
    JOIN `wadmysql3`.`order details`
      ON ((`wadmysql3`.`products`.`ProductID` = `wadmysql3`.`order details`.`ProductID`)));
