CREATE VIEW `alphabetical list of products` AS
  SELECT
    `wadmysql3`.`products`.`ProductID`       AS `ProductID`,
    `wadmysql3`.`products`.`ProductName`     AS `ProductName`,
    `wadmysql3`.`products`.`SupplierID`      AS `SupplierID`,
    `wadmysql3`.`products`.`CategoryID`      AS `CategoryID`,
    `wadmysql3`.`products`.`QuantityPerUnit` AS `QuantityPerUnit`,
    `wadmysql3`.`products`.`UnitPrice`       AS `UnitPrice`,
    `wadmysql3`.`products`.`UnitsInStock`    AS `UnitsInStock`,
    `wadmysql3`.`products`.`UnitsOnOrder`    AS `UnitsOnOrder`,
    `wadmysql3`.`products`.`ReorderLevel`    AS `ReorderLevel`,
    `wadmysql3`.`products`.`Discontinued`    AS `Discontinued`,
    `wadmysql3`.`categories`.`CategoryName`  AS `CategoryName`
  FROM (`wadmysql3`.`categories`
    JOIN `wadmysql3`.`products` ON ((`wadmysql3`.`categories`.`CategoryID` = `wadmysql3`.`products`.`CategoryID`)))
  WHERE (`wadmysql3`.`products`.`Discontinued` = 0);
