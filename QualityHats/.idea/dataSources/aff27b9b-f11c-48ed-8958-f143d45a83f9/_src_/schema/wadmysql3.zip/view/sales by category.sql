CREATE VIEW `sales by category` AS
  SELECT
    `wadmysql3`.`categories`.`CategoryID`         AS `CategoryID`,
    `wadmysql3`.`categories`.`CategoryName`       AS `CategoryName`,
    `wadmysql3`.`products`.`ProductName`          AS `ProductName`,
    sum(`order details extended`.`ExtendedPrice`) AS `ProductSales`
  FROM (((`wadmysql3`.`categories`
    JOIN `wadmysql3`.`products` ON ((`wadmysql3`.`categories`.`CategoryID` = `wadmysql3`.`products`.`CategoryID`))) JOIN
    `wadmysql3`.`order details extended`
      ON ((`wadmysql3`.`products`.`ProductID` = `order details extended`.`ProductID`))) JOIN `wadmysql3`.`orders`
      ON ((`wadmysql3`.`orders`.`OrderID` = `order details extended`.`OrderID`)))
  WHERE (`wadmysql3`.`orders`.`OrderDate` BETWEEN '1997-01-01' AND '1997-12-31')
  GROUP BY `wadmysql3`.`categories`.`CategoryID`, `wadmysql3`.`categories`.`CategoryName`,
    `wadmysql3`.`products`.`ProductName`;
