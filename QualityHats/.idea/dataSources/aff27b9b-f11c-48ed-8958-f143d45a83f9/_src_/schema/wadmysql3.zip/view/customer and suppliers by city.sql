CREATE VIEW `customer and suppliers by city` AS
  SELECT
    `wadmysql3`.`customers`.`City`        AS `City`,
    `wadmysql3`.`customers`.`CompanyName` AS `CompanyName`,
    `wadmysql3`.`customers`.`ContactName` AS `ContactName`,
    'Customers'                           AS `Relationship`
  FROM `wadmysql3`.`customers`
  UNION SELECT
          `wadmysql3`.`suppliers`.`City`        AS `City`,
          `wadmysql3`.`suppliers`.`CompanyName` AS `CompanyName`,
          `wadmysql3`.`suppliers`.`ContactName` AS `ContactName`,
          'Suppliers'                           AS `Suppliers`
        FROM `wadmysql3`.`suppliers`
  ORDER BY `City`, `CompanyName`;
